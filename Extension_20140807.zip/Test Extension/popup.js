function gebi(x)
{
return document.getElementById(x)
}

function showtoggle(x)
{
  obj = gebi(x)
  if (obj.style.display == 'none') {obj.style.display='block';}
  else {obj.style.display='none';}
}

myurl = ""

chrome.tabs.getSelected(null,function(tab) {
    currenturl = tab.url+""
    currenttitle = tab.title+""
    myurl = "http://www.tidblitz.com/SiteRate/default/siteinfo_ext?siteurl="+currenturl+"&title="+currenttitle
    gebi('tidblitziframe').src=myurl

});


