
/* Try this */
var s = document.createElement('script');
s.src = chrome.extension.getURL('script_2.js');
(document.head||document.documentElement).appendChild(s);
s.onload = function() {
    s.parentNode.removeChild(s);
};