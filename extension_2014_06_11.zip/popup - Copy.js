var current_url = ""
/*
chrome.tabs.getSelected(null,function(tab) {
   //current_url = tab.url;
   //document.getElementById('siteurl').value=tab.url+""
  puturl(tab.url)
});
*/
function puturl(link)
{
document.getElementById('siteurl').value=link;
current_url=link;
console.log(link);
}

chrome.tabs.query({'active': true, 'lastFocusedWindow': true,'currentWindow': true}, function (tabs) {
    puturl(tabs[0].url);
});